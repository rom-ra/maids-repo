package com.example.LibraryApi.Entities;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

public class Patron {
    private UUID id;
    private final String name;
    private final String contactInfo;
    private final List<BorrowingRecord> borrowingRecords;

    public Patron(
            @JsonProperty("id") UUID id,
            @JsonProperty("name") String name,
            @JsonProperty("contactInfo") String contactInfo,
            @JsonProperty("borrowingRecords") List<BorrowingRecord> borrowingRecords) {
        this.id = id;
        this.name = name;
        this.contactInfo = contactInfo;
        this.borrowingRecords = borrowingRecords;
    }

    public UUID getId() {
        return id;
    }
    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public List<BorrowingRecord> getBorrowingRecords() {
        return borrowingRecords;
    }
}
