package com.example.LibraryApi.Repositories;



import com.example.LibraryApi.Entities.Patron;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatronRepository extends JpaRepository<Patron, Long> {
}
