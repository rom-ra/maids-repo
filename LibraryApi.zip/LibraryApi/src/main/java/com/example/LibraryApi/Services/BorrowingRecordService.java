package com.example.LibraryApi.Services;

// src/main/java/com/example/library/service/BorrowingRecordService.java

import com.example.LibraryApi.Entities.Book;
import com.example.LibraryApi.Entities.BorrowingRecord;
import com.example.LibraryApi.Entities.Patron;
import com.example.LibraryApi.Repositories.BookRepository;
import com.example.LibraryApi.Repositories.BorrowingRecordRepository;
import com.example.LibraryApi.Repositories.PatronRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Optional;

@Service
public class BorrowingRecordService {
    @Autowired
    private BorrowingRecordRepository borrowingRecordRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private PatronRepository patronRepository;

    @Transactional
    public BorrowingRecord borrowBook(Long bookId, Long patronId) {
        Optional<Book> book = bookRepository.findById(bookId);
        Optional<Patron> patron = patronRepository.findById(patronId);
        if (book.isPresent() && patron.isPresent()) {
            BorrowingRecord record = new BorrowingRecord();
            record.setBook(book.get());
            record.setPatron(patron.get());
            record.setBorrowDate(LocalDate.now());
            return borrowingRecordRepository.save(record);
        }
        throw new RuntimeException("Book or Patron not found");
    }

    @Transactional
    public BorrowingRecord returnBook(Long bookId, Long patronId) {
        Optional<Book> book = bookRepository.findById(bookId);
        Optional<Patron> patron = patronRepository.findById(patronId);
        if (book.isPresent() && patron.isPresent()) {
            BorrowingRecord record = borrowingRecordRepository.findByBookAndPatron(book.get(), patron.get());
            if (record != null) {
                record.setReturnDate(LocalDate.now());
                return borrowingRecordRepository.save(record);
            }
        }
        throw new RuntimeException("Borrowing Record not found");
    }
}
