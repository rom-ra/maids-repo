package com.example.LibraryApi.Entities;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

public class Book {
    private final UUID id;
    private final String title;
    private final String author;
    private final int publicationYear;
    private final String isbn;
    private final List<BorrowingRecord> borrowingRecords;

    public Book(
            @JsonProperty("id") UUID id,
            @JsonProperty("title") String title,
            @JsonProperty("author") String author,
            @JsonProperty("publicationYear") int publicationYear,
            @JsonProperty("isbn") String isbn,
            @JsonProperty("borrowingRecords") List<BorrowingRecord> borrowingRecords) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.isbn = isbn;
        this.borrowingRecords = borrowingRecords;
    }

    public UUID getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public String getIsbn() {
        return isbn;
    }

    public List<BorrowingRecord> getBorrowingRecords() {
        return borrowingRecords;
    }
}
