package com.example.LibraryApi.Entities;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDate;
import java.util.UUID;

public class BorrowingRecord {
    private UUID id;
    private LocalDate borrowDate;
    private LocalDate returnDate;
    private Book book;
    private Patron patron;

    public BorrowingRecord(
            @JsonProperty("id") UUID id,
            @JsonProperty("borrowDate") LocalDate borrowDate,
            @JsonProperty("returnDate") LocalDate returnDate,
            @JsonProperty("book") Book book,
            @JsonProperty("patron") Patron patron) {
        this.id = id;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.book = book;
        this.patron = patron;
    }

    public BorrowingRecord() {

    }

    // Getters
    public UUID getId() {
        return id;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public Book getBook() {
        return book;
    }

    public Patron getPatron() {
        return patron;
    }

    // Setters
    public void setId(UUID id) {
        this.id = id;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public void setPatron(Patron patron) {
        this.patron = patron;
    }
}
