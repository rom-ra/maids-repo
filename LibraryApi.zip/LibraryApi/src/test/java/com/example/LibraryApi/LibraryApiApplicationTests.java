package com.example.LibraryApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
